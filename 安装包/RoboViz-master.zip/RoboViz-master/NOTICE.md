**NOTICE file corresponding to section 4(d) of the Apache License, Version 2.0.**                                                

This product includes software developed by the following individuals:
- Justin Stoecker
- Klaus Dorer
- Jens Fischer
- Patrick MacAlpine
