#!/bin/bash

EXT=macosx/
./bash-build.sh ../bin/$EXT ../lib/jogl-2.0/$EXT
