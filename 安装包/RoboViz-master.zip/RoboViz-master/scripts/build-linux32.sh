#!/bin/bash

EXT=linux-i586/
./bash-build.sh ../bin/$EXT ../lib/jogl-2.0/$EXT
