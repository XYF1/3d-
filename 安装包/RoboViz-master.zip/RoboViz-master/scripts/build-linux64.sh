#!/bin/bash

EXT=linux-amd64/
./bash-build.sh ../bin/$EXT ../lib/jogl-2.0/$EXT
