/* This file is generated automatically by make_sin.pl
 -- Don't edit this file!*/
#ifndef __SINE_FIXED__ 
#define __SINE_FIXED__ 
#define INT_MAXX 1073741824
#define INT_MAXE 30
#define PFACTOR 500
int cos_fixed(int);
int sin_fixed(int);
#endif
